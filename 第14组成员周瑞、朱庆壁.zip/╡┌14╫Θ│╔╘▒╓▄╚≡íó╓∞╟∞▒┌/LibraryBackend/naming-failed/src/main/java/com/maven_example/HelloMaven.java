package com.maven_example;

public class HelloMaven{
    public String say(String name){
        String res = "Hello " + name;
        System.out.printf("%s\n", res);
        return res;
    }
}
