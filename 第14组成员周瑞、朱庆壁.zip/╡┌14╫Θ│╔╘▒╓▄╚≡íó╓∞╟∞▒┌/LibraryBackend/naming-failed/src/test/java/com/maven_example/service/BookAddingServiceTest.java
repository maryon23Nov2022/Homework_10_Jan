package com.maven_example.service;

import org.junit.Test;

public class BookAddingServiceTest{
    @Test
    public void testDoPost(){

    }
}
