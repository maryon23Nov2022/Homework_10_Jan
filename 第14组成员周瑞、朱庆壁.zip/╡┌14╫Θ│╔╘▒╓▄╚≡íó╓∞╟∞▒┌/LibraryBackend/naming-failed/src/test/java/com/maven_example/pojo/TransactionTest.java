package com.maven_example.pojo;

import org.junit.Test;

public class TransactionTest{

    @Test
    public void testGetDate(){
        Transaction transaction = new Transaction();
    }
}
